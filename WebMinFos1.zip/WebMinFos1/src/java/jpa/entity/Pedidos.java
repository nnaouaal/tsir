package jpa.entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@Entity
@Table(name = "pedidos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Pedidos.findAll", query = "SELECT p FROM Pedidos p"),
    @NamedQuery(name = "Pedidos.findByNumero", query = "SELECT p FROM Pedidos p WHERE p.pedidosPK.numero = :numero"),
    @NamedQuery(name = "Pedidos.findByFecha", query = "SELECT p FROM Pedidos p WHERE p.fecha = :fecha")
})
public class Pedidos implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    protected PedidosPK pedidosPK;

    @Column(name = "fecha")
    @Temporal(TemporalType.DATE)
    private Date fecha;

    @JoinTable(name = "pedidos_has_productos", joinColumns = {
        @JoinColumn(name = "pedidos_numero", referencedColumnName = "numero"),
        @JoinColumn(name = "pedidos_clientes_NIF", referencedColumnName = "clientes_NIF")
    }, inverseJoinColumns = {
        @JoinColumn(name = "productos_idproductos", referencedColumnName = "idproductos"),
        @JoinColumn(name = "productos_categorias_idcategorias", referencedColumnName = "categorias_idcategorias")
    })
    @ManyToMany
    private Collection<Productos> productosCollection;

    @JoinColumn(name = "clientes_NIF", referencedColumnName = "NIF", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Clientes clientes;

    public Pedidos() { }

    public Pedidos(PedidosPK pedidosPK) {
        this.pedidosPK = pedidosPK;
    }

    public Pedidos(int numero, String clientesNIF) {
        this.pedidosPK = new PedidosPK(numero, clientesNIF);
    }

    public PedidosPK getPedidosPK() {
        return pedidosPK;
    }

    public void setPedidosPK(PedidosPK pedidosPK) {
        this.pedidosPK = pedidosPK;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @XmlTransient
    public Collection<Productos> getProductosCollection() {
        return productosCollection;
    }

    public void setProductosCollection(Collection<Productos> productosCollection) {
        this.productosCollection = productosCollection;
    }

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pedidosPK != null ? pedidosPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Pedidos)) {
            return false;
        }
        Pedidos other = (Pedidos) object;
        if ((this.pedidosPK == null && other.pedidosPK != null) || (this.pedidosPK != null && !this.pedidosPK.equals(other.pedidosPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.entity.Pedidos[ pedidosPK=" + pedidosPK + " ]";
    }
}
