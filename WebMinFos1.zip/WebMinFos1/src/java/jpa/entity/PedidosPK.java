/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author nkhamou
 */
@Embeddable
public class PedidosPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "numero")
    private int numero;
    @Basic(optional = false)
    //@NotNull
    //@Size(min = 1, max = 9)
    @Column(name = "clientes_NIF")
    private String clientesNIF;

    public PedidosPK() {
    }

    public PedidosPK(int numero, String clientesNIF) {
        this.numero = numero;
        this.clientesNIF = clientesNIF;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getClientesNIF() {
        return clientesNIF;
    }

    public void setClientesNIF(String clientesNIF) {
        this.clientesNIF = clientesNIF;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) numero;
        hash += (clientesNIF != null ? clientesNIF.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PedidosPK)) {
            return false;
        }
        PedidosPK other = (PedidosPK) object;
        if (this.numero != other.numero) {
            return false;
        }
        if ((this.clientesNIF == null && other.clientesNIF != null) || (this.clientesNIF != null && !this.clientesNIF.equals(other.clientesNIF))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.entity.PedidosPK[ numero=" + numero + ", clientesNIF=" + clientesNIF + " ]";
    }
    
}
