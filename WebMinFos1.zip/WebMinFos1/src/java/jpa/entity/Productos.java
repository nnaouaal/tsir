package jpa.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "productos")
@NamedQueries({
    @NamedQuery(name = "Productos.findAll", query = "SELECT p FROM Productos p"),
    @NamedQuery(name = "Productos.findByNombre", query = "SELECT p FROM Productos p WHERE p.nombre = :nombre")
})
public class Productos implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private ProductosPK productosPK;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "lugarExp")
    private String lugarExp;

    @Column(name = "fechaExp")
    @Temporal(TemporalType.DATE)
    private Date fechaExp;

    @Column(name = "edadEstimada")
    private String edadEstimada;

    @Column(name = "precio")
    private Double precio;

    @MapsId("categoriasIdcategorias")
    @JoinColumn(name = "categorias_idcategorias", referencedColumnName = "idcategorias")
    @ManyToOne(optional = false)
    private Categorias categorias;

    public Productos() {
        this.productosPK = new ProductosPK();
    }

    public Productos(ProductosPK productosPK) {
        this.productosPK = productosPK;
    }

    public ProductosPK getProductosPK() {
        return productosPK;
    }

    public void setProductosPK(ProductosPK productosPK) {
        this.productosPK = productosPK;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLugarExp() {
        return lugarExp;
    }

    public void setLugarExp(String lugarExp) {
        this.lugarExp = lugarExp;
    }

    public Date getFechaExp() {
        return fechaExp;
    }

    public void setFechaExp(Date fechaExp) {
        this.fechaExp = fechaExp;
    }

    public String getEdadEstimada() {
        return edadEstimada;
    }

    public void setEdadEstimada(String edadEstimada) {
        this.edadEstimada = edadEstimada;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Categorias getCategorias() {
        return categorias;
    }

    public void setCategorias(Categorias categorias) {
        this.categorias = categorias;
        if (categorias != null) {
            if (this.productosPK == null) this.productosPK = new ProductosPK();
            this.productosPK.setCategoriasIdcategorias(categorias.getIdcategorias());
        }
    }

    @Override
    public int hashCode() {
        return (productosPK != null ? productosPK.hashCode() : 0);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Productos)) {
            return false;
        }
        Productos other = (Productos) object;
        return (this.productosPK != null || other.productosPK == null)
            && (this.productosPK == null || this.productosPK.equals(other.productosPK));
    }

    @Override
    public String toString() {
        return "jpa.entity.Productos[ productosPK=" + productosPK + " ]";
    }
}

