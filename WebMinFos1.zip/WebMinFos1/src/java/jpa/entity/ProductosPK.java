package jpa.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ProductosPK implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "idproductos")
    private Integer idproductos;

    @Column(name = "categorias_idcategorias", length = 3)
    private String categoriasIdcategorias;

    public ProductosPK() { }

    public ProductosPK(Integer idproductos, String categoriasIdcategorias) {
        this.idproductos = idproductos;
        this.categoriasIdcategorias = categoriasIdcategorias;
    }

    public Integer getIdproductos() {
        return idproductos;
    }

    public void setIdproductos(Integer idproductos) {
        this.idproductos = idproductos;
    }

    public String getCategoriasIdcategorias() {
        return categoriasIdcategorias;
    }

    public void setCategoriasIdcategorias(String categoriasIdcategorias) {
        this.categoriasIdcategorias = categoriasIdcategorias;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idproductos, categoriasIdcategorias);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof ProductosPK)) return false;
        ProductosPK other = (ProductosPK) obj;
        return Objects.equals(this.idproductos, other.idproductos)
            && Objects.equals(this.categoriasIdcategorias, other.categoriasIdcategorias);
    }

    @Override
    public String toString() {
        return "jpa.entity.ProductosPK[ idproductos=" + idproductos + ", categoriasIdcategorias=" + categoriasIdcategorias + " ]";
    }
}
