package jpa.session;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import jpa.entity.Categorias;

@Stateless
public class CategoriasFacade extends AbstractFacade<Categorias> {

    @PersistenceContext(unitName = "WebMinFosPU")
    private EntityManager em;

    public CategoriasFacade() {
        super(Categorias.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Devuelve lista de nombres de categoría (útil para selectItems).
     */
    public List<String> listaNombres() {
        TypedQuery<String> q = em.createQuery("SELECT c.nombre FROM Categorias c ORDER BY c.nombre", String.class);
        return q.getResultList();
    }

    /**
     * Busca una categoría por su nombre. Devuelve null si no existe.
     */
    public Categorias findByNombre(String nombre) {
        if (nombre == null) return null;
        try {
            TypedQuery<Categorias> q = em.createQuery("SELECT c FROM Categorias c WHERE c.nombre = :n", Categorias.class);
            q.setParameter("n", nombre);
            return q.getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }
}
