package jpa.session;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import jpa.entity.Clientes;

@Stateless
public class ClientesFacade extends AbstractFacade<Clientes> {

    @PersistenceContext(unitName = "WebMinFosPU")
    private EntityManager em;

    public ClientesFacade() {
        super(Clientes.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Devuelve todos los clientes ordenados por nombre.
     */
    public List<Clientes> findAllClientes() {
        TypedQuery<Clientes> q = em.createQuery("SELECT c FROM Clientes c ORDER BY c.nombre", Clientes.class);
        return q.getResultList();
    }

    /**
     * Buscar cliente por NIF (clave primaria).
     */
    public Clientes findByNIF(String nif) {
        if (nif == null) return null;
        return em.find(Clientes.class, nif);
    }
}

