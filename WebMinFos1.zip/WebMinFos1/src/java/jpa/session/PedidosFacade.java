package jpa.session;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import jpa.entity.Pedidos;

@Stateless
public class PedidosFacade extends AbstractFacade<Pedidos> {

    @PersistenceContext(unitName = "WebMinFosPU")
    private EntityManager em;

    public PedidosFacade() {
        super(Pedidos.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Lista pedidos de un cliente (por NIF).
     * Ajustado al mapeo: la entidad Pedidos tiene la relación 'clientes' y la PK es pedidosPK.
     */
    public List<Pedidos> listaPorCliente(String nifCliente) {
        TypedQuery<Pedidos> q = em.createQuery(
            "SELECT p FROM Pedidos p WHERE p.clientes.nif = :n ORDER BY p.pedidosPK.numero", Pedidos.class);
        q.setParameter("n", nifCliente);
        return q.getResultList();
    }
}


