package jpa.session;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import jpa.entity.Productos;
import jpa.entity.ProductosPK;
import jpa.entity.Categorias;

@Stateless
public class ProductosFacade extends AbstractFacade<Productos> {

    @PersistenceContext(unitName = "WebMinFosPU")
    private EntityManager em;

    public ProductosFacade() {
        super(Productos.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Lista productos por nombre de categoría.
     */
    public List<Productos> listaPorCategoria(String nombreCategoria) {
        TypedQuery<Productos> q = em.createQuery(
            "SELECT p FROM Productos p WHERE p.categorias.nombre = :n ORDER BY p.nombre", Productos.class);
        q.setParameter("n", nombreCategoria);
        return q.getResultList();
    }

    /**
     * Añade un producto asignándolo a la categoría indicada por nombre.
     * Genera idproductos con MAX(idproductos)+1 (solución simple para el esquema con PK compuesta).
     */
    public void addProducto(String nombreCategoria, Productos p) {
        Categorias c;
        try {
            TypedQuery<Categorias> q = em.createQuery("SELECT c FROM Categorias c WHERE c.nombre = :n", Categorias.class);
            q.setParameter("n", nombreCategoria);
            c = q.getSingleResult();
        } catch (NoResultException ex) {
            throw new IllegalArgumentException("Categoría no encontrada: " + nombreCategoria, ex);
        }

        // calcular siguiente id (simple). En entornos concurrentes usar otra estrategia.
        Object maxObj = em.createNativeQuery("SELECT COALESCE(MAX(idproductos),0) FROM productos").getSingleResult();
        int nextId;
        if (maxObj instanceof Number) {
            nextId = ((Number) maxObj).intValue() + 1;
        } else {
            nextId = Integer.parseInt(maxObj.toString()) + 1;
        }

        ProductosPK pk = new ProductosPK();
        pk.setIdproductos(nextId);
        pk.setCategoriasIdcategorias(c.getIdcategorias());
        p.setProductosPK(pk);
        p.setCategorias(c);

        em.persist(p);
    }

    /**
     * Elimina un producto por su PK compuesta.
     */
    public void removeByPK(ProductosPK pk) {
        if (pk == null) return;
        Productos managed = em.find(Productos.class, pk);
        if (managed != null) {
            em.remove(managed);
        }
    }

    public List<Productos> findByCategoria(Categorias cat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

