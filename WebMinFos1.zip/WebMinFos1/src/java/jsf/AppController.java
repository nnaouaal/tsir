package jsf;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import jpa.entity.Productos;
import jpa.entity.ProductosPK;
import jpa.entity.Categorias;
import jpa.entity.Clientes;
import jpa.session.CategoriasFacade;
import jpa.session.ProductosFacade;
import jpa.session.ClientesFacade;

@Named(value = "appController")
@SessionScoped
public class AppController implements Serializable {

    private static final long serialVersionUID = 1L;

    // --- Facades inyectados ---
    @EJB
    private CategoriasFacade categoriasFacade;

    @EJB
    private ProductosFacade productosFacade;

    @EJB
    private ClientesFacade clientesFacade;

    // --- Categorías / Productos ---
    private List<String> listaNombres;
    private String nombreCategoriaSeleccionada;
    private List<Productos> listaProductos;

    // Campos para alta/edición de productos
    private Productos nuevoProducto;
    private String categoriaParaAlta;
    private Productos productoSeleccionado;

    // --- Clientes: listado, selección y paginación ---
    private List<Clientes> listaClientesAll;      // todos los clientes
    private List<Clientes> listaClientesPage;     // sublista para la página actual
    private int page = 1;
    private int pageSize = 10;
    private int totalPages = 1;

    // Selección y formulario de cliente
    private Clientes clienteSeleccionado;
    private Clientes nuevoCliente;

    public AppController() { }

    @PostConstruct
    public void init() {
        // cargar nombres de categorías
        try {
            if (categoriasFacade != null) {
                listaNombres = categoriasFacade.listaNombres();
            } else {
                listaNombres = new ArrayList<>();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            listaNombres = new ArrayList<>();
        }

        // inicializar producto y cliente por defecto
        nuevoProducto = new Productos();
        categoriaParaAlta = (listaNombres != null && !listaNombres.isEmpty()) ? listaNombres.get(0) : null;
        nuevoCliente = new Clientes();

        // cargar clientes para la gestión (paginación)
        cargarClientes();
    }

    // ---------------- Seguridad / utilidades ----------------
    public boolean isAdmin() {
        FacesContext fc = FacesContext.getCurrentInstance();
        if (fc == null || fc.getExternalContext() == null) {
            return false;
        }
        // Comprueba el rol 'minfosAdmin' (ajusta si tu rol tiene otro nombre)
        return fc.getExternalContext().isUserInRole("minfosAdmin");
    }

    // ---------------- Navegación y acciones Productos ----------------

    // Invocado desde productosList.xhtml (botón Nuevo Producto)
    public String prepararAltaProducto() {
        this.nuevoProducto = new Productos();
        this.categoriaParaAlta = (listaNombres != null && !listaNombres.isEmpty()) ? listaNombres.get(0) : null;
        return "productos_alta.xhtml?faces-redirect=true";
    }

    // Alternativa genérica (si alguna vista usa prepararAlta)
    public String prepararAlta() {
        return prepararAltaProducto();
    }

    // Ver ficha (botón Ver)
    public String verFichaProducto(Productos p) {
        if (p == null) return null;
        this.productoSeleccionado = p;
        return "productoView.xhtml?faces-redirect=true";
    }

    // Preparar edición (botón Editar)
    public String prepararEditarProducto(Productos p) {
        if (p == null) return null;
        this.productoSeleccionado = p;
        return "productos_editar.xhtml?faces-redirect=true";
    }

    // Guardar cambios desde la página de edición
    public String saveProducto() {
        if (productoSeleccionado == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "No hay producto para guardar"));
            return null;
        }
        try {
            productosFacade.edit(productoSeleccionado);
            if (nombreCategoriaSeleccionada != null) {
                listaProductos = productosFacade.listaPorCategoria(nombreCategoriaSeleccionada);
            }
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Producto actualizado"));
            return "productosList.xhtml?faces-redirect=true";
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No se pudo guardar: " + ex.getMessage()));
            return null;
        }
    }

    // Borrar producto desde la lista (firma usada en la vista: deleteProducto(p))
    public String deleteProducto(Productos p) {
        if (p == null || p.getProductosPK() == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "No hay producto seleccionado"));
            return null;
        }
        try {
            ProductosPK pk = p.getProductosPK();
            productosFacade.removeByPK(pk);
            if (nombreCategoriaSeleccionada != null) {
                listaProductos = productosFacade.listaPorCategoria(nombreCategoriaSeleccionada);
            } else {
                listaProductos = null;
            }
            if (productoSeleccionado != null && productoSeleccionado.equals(p)) {
                productoSeleccionado = null;
            }
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Producto eliminado"));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No se pudo eliminar: " + ex.getMessage()));
        }
        return null; // permanecer en la misma página
    }

    // Método auxiliar que usa la ficha para volver a la lista de productos por categoría
    public String verProductosPorCategoria() {
        if (nombreCategoriaSeleccionada != null) {
            listaProductos = productosFacade.listaPorCategoria(nombreCategoriaSeleccionada);
        } else {
            listaProductos = null;
        }
        return "productosList.xhtml?faces-redirect=true";
    }

    // Acción de alta: delega en el facade
    public String addProducto() {
        String destino = (categoriaParaAlta != null && !categoriaParaAlta.isEmpty()) ? categoriaParaAlta : nombreCategoriaSeleccionada;
        if (destino == null || destino.isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Debe seleccionar una categoría"));
            return null;
        }
        try {
            productosFacade.addProducto(destino, nuevoProducto);
            if (destino.equals(nombreCategoriaSeleccionada)) {
                listaProductos = productosFacade.listaPorCategoria(nombreCategoriaSeleccionada);
            }
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Producto creado correctamente"));
            return "productosList.xhtml?faces-redirect=true";
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", ex.getMessage()));
            return null;
        }
    }

    // Listener para selectOneMenu (si lo usas)
    public void valueChangeListener(ValueChangeEvent event) {
        Object newValue = event.getNewValue();
        nombreCategoriaSeleccionada = (newValue != null) ? newValue.toString() : null;
        // forzar recarga de productos
        this.listaProductos = null;
    }

    // ---------------- Clientes: carga, selección, CRUD y paginación ----------------

    private void cargarClientes() {
        try {
            if (clientesFacade != null) {
                listaClientesAll = clientesFacade.findAllClientes();
            } else {
                listaClientesAll = new ArrayList<>();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            listaClientesAll = new ArrayList<>();
        }
        // inicializar paginación
        page = 1;
        calcularTotalPages();
        cargarPagina();
    }

    private void calcularTotalPages() {
        if (listaClientesAll == null || listaClientesAll.isEmpty()) {
            totalPages = 1;
        } else {
            totalPages = (int) Math.ceil((double) listaClientesAll.size() / pageSize);
            if (totalPages < 1) totalPages = 1;
        }
    }

    private void cargarPagina() {
        listaClientesPage = new ArrayList<>();
        if (listaClientesAll == null || listaClientesAll.isEmpty()) return;
        int fromIndex = (page - 1) * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, listaClientesAll.size());
        if (fromIndex >= 0 && fromIndex < toIndex) {
            listaClientesPage = listaClientesAll.subList(fromIndex, toIndex);
        }
    }

    public List<Clientes> getListaClientesPage() {
        if (listaClientesPage == null) {
            cargarClientes();
        }
        return listaClientesPage;
    }

    public int getPage() { return page; }
    public int getTotalPages() { return totalPages; }

    public void prevPage() {
        if (page > 1) {
            page--;
            cargarPagina();
        }
    }

    public void nextPage() {
        if (page < totalPages) {
            page++;
            cargarPagina();
        }
    }

    public void refreshClientes() {
        cargarClientes();
    }

    // Preparar alta de cliente
    public String prepararAltaCliente() {
        this.nuevoCliente = new Clientes();
        return "cliente_alta.xhtml?faces-redirect=true";
    }

    // Preparar edición: carga el cliente en el formulario
    public String prepararEditarCliente(Clientes c) {
        if (c == null) return null;
        this.nuevoCliente = c;
        return "cliente_editar.xhtml?faces-redirect=true";
    }

    // Guardar cliente (alta o edición)
    public String saveCliente() {
        if (this.nuevoCliente == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "No hay cliente para guardar"));
            return null;
        }
        try {
            Clientes existing = clientesFacade.find(this.nuevoCliente.getNif());
            if (existing == null) {
                clientesFacade.create(this.nuevoCliente);
            } else {
                clientesFacade.edit(this.nuevoCliente);
            }
            cargarClientes();
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Cliente guardado"));
            return "clientes.xhtml?faces-redirect=true";
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No se pudo guardar: " + ex.getMessage()));
            return null;
        }
    }

    // Borrar cliente (recibe la entidad desde la vista)
    public String deleteCliente(Clientes c) {
        if (c == null || c.getNif() == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "No hay cliente seleccionado"));
            return null;
        }
        try {
            Clientes managed = clientesFacade.find(c.getNif());
            if (managed != null) {
                clientesFacade.remove(managed);
                cargarClientes();
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Cliente eliminado"));
            }
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No se pudo eliminar: " + ex.getMessage()));
        }
        return null;
    }
    

    // Navegar a clientes (opcional, usado si prefieres commandButton en template)
    public String irClientes() {
        cargarClientes();
        return "clientes.xhtml?faces-redirect=true";
    }

    // ---------------- Getters / Setters ----------------

    // Categorías / productos
    public List<String> getListaNombres() { return listaNombres; }
    public void setListaNombres(List<String> listaNombres) { this.listaNombres = listaNombres; }

    public String getNombreCategoriaSeleccionada() { return nombreCategoriaSeleccionada; }
    public void setNombreCategoriaSeleccionada(String nombreCategoriaSeleccionada) {
        this.nombreCategoriaSeleccionada = nombreCategoriaSeleccionada;
        this.listaProductos = null; // forzar recarga
    }
/**
 * Devuelve la lista de nombres de categorías. Si no está cargada,
 * la solicita al facade y la inicializa.
 * Método público para ser invocado desde las vistas (#{appController.cargarCategorias()}).
 */
public List<String> cargarCategorias() {
    if (this.listaNombres == null || this.listaNombres.isEmpty()) {
        try {
            this.listaNombres = categoriasFacade.listaNombres();
        } catch (Exception ex) {
            // En caso de error, inicializamos lista vacía y registramos mensaje
            this.listaNombres = new java.util.ArrayList<>();
            javax.faces.context.FacesContext.getCurrentInstance().addMessage(null,
                new javax.faces.application.FacesMessage(javax.faces.application.FacesMessage.SEVERITY_ERROR,
                    "Error", "No se pudieron cargar las categorías: " + ex.getMessage()));
            ex.printStackTrace();
        }
        if (this.listaNombres == null) {
            this.listaNombres = new java.util.ArrayList<>();
        }
    }
    return this.listaNombres;
}

    public List<Productos> getListaProductos() {
        if (this.listaProductos == null) {
            if (this.nombreCategoriaSeleccionada != null && !this.nombreCategoriaSeleccionada.isEmpty()) {
                try {
                    this.listaProductos = productosFacade.listaPorCategoria(this.nombreCategoriaSeleccionada);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    this.listaProductos = new ArrayList<>();
                    FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No se pudieron cargar los productos"));
                }
            } else {
                this.listaProductos = new ArrayList<>();
            }
        }
        return this.listaProductos;
    }
    public void setListaProductos(List<Productos> listaProductos) { this.listaProductos = listaProductos; }

    public Productos getNuevoProducto() {
        if (this.nuevoProducto == null) this.nuevoProducto = new Productos();
        return nuevoProducto;
    }
    public void setNuevoProducto(Productos nuevoProducto) { this.nuevoProducto = nuevoProducto; }

    public String getCategoriaParaAlta() { return categoriaParaAlta; }
    public void setCategoriaParaAlta(String categoriaParaAlta) { this.categoriaParaAlta = categoriaParaAlta; }

    public Productos getProductoSeleccionado() { return productoSeleccionado; }
    public void setProductoSeleccionado(Productos productoSeleccionado) { this.productoSeleccionado = productoSeleccionado; }

    // Clientes
    public List<Clientes> getListaClientesAll() { return listaClientesAll; }
    public void setListaClientesAll(List<Clientes> listaClientesAll) { this.listaClientesAll = listaClientesAll; }

    public Clientes getClienteSeleccionado() { return clienteSeleccionado; }
    public void setClienteSeleccionado(Clientes clienteSeleccionado) { this.clienteSeleccionado = clienteSeleccionado; }

    public Clientes getNuevoCliente() {
        if (this.nuevoCliente == null) this.nuevoCliente = new Clientes();
        return nuevoCliente;
    }
    public void setNuevoCliente(Clientes nuevoCliente) { this.nuevoCliente = nuevoCliente; }

    public void setListaClientesPage(List<Clientes> listaClientesPage) { this.listaClientesPage = listaClientesPage; }

    // Paginación getters
    public int getPageSize() { return pageSize; }
    public void setPageSize(int pageSize) { this.pageSize = pageSize; }

    // Volver al índice
    public String volverPrincipal() {
        return "index.xhtml?faces-redirect=true";
    }
}
