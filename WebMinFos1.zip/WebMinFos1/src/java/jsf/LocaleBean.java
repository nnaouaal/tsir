package jsf;

import java.io.Serializable;
import java.util.Locale;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named("localeBean")
@SessionScoped
public class LocaleBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // Código de idioma (ej. "es", "en")
    private String language = "es";

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
        applyLocale();
    }

    // Devuelve el Locale actual (útil para f:view locale)
    public Locale getLocale() {
        return new Locale(language);
    }

    // Aplica la locale al ViewRoot actual
    public void applyLocale() {
        FacesContext fc = FacesContext.getCurrentInstance();
        if (fc != null) {
            if (fc.getViewRoot() != null) {
                fc.getViewRoot().setLocale(getLocale());
            }
        }
    }
}
